package com.example.mygame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btn1;
    TextView tv;
    EditText txt1;
    EditText txt2;
    int i;
    int j;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = (Button)findViewById(R.id.nextpicture);
        tv = (TextView)findViewById(R.id.animal);
        txt1 = (EditText)findViewById(R.id.edittext);
        txt2 = (EditText)findViewById(R.id.score);
        txt2.setText("0");
        i=0;
        j=0;
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view ){
                switch(i){
                    case 0:
                        tv.setBackgroundResource(R.drawable.bird);
                        if(txt1.getText().toString().equals("bear"))
                       {
                          j++;
                          String s = String.valueOf(j);
                          txt2.setText(s);
                       }
                       i++;
                       break;
                    case 1:

                        if(txt1.getText().toString().equals("bird"))
                        {tv.setBackgroundResource(R.drawable.cat);
                            j++;
                            String s = String.valueOf(j);
                            txt2.setText(s);
                        }
                        i++;
                        break;
                    case 2:
                        tv.setBackgroundResource(R.drawable.fish);
                        if(txt1.getText().toString().equals("cat"))
                        {
                            j++;
                            String s = String.valueOf(j);
                            txt2.setText(s);
                        }
                         i++;
                         break;
                    case 3:
                        tv.setBackgroundResource(R.drawable.flower);
                        if(txt1.getText().toString().equals("fish"))
                        {
                            j++;
                            String s = String.valueOf(j);
                            txt2.setText(s);
                        }
                        i++;
                        break;
                    case 4:
                        tv.setBackgroundResource(R.drawable.bear);
                        if(txt1.getText().toString().equals("flower"))
                        {
                            j++;
                            String s = String.valueOf(j);
                            txt2.setText(s);
                        }
                         i++;
                         break;
                }
                if(i >= 5)
                {i = 0;}
            }
        });
    }
}
